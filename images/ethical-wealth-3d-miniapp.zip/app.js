import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// --- DOM elements
const canvas = document.getElementById('scene');
const tipCounter = document.getElementById('tipCounter');
const timerEl = document.getElementById('timer');
const tooltip = document.getElementById('tooltip');
const startBtn = document.getElementById('startBtn');
const howBtn = document.getElementById('howBtn');
const howModal = document.getElementById('howModal');
const closeHow = document.getElementById('closeHow');
const ctaBar = document.getElementById('ctaBar');
const endModal = document.getElementById('endModal');
const finalTime = document.getElementById('finalTime');
const leadForm = document.getElementById('leadForm');
const replayBtn = document.getElementById('replayBtn');

// --- Analytics helper
function pushEvent(name, detail={}){
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ event: name, ...detail });
}

// --- Scene setup
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf6f8fb);

const camera = new THREE.PerspectiveCamera(55, window.innerWidth/window.innerHeight, 0.1, 100);
camera.position.set(3.5, 2.2, 3.8);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.enablePan = false;
controls.minDistance = 2;
controls.maxDistance = 8;
controls.target.set(0,1.1,0);

// Light
const hemi = new THREE.HemisphereLight(0xffffff, 0xaaaaaa, 1.0);
scene.add(hemi);
const dir = new THREE.DirectionalLight(0xffffff, 0.8);
dir.position.set(2,5,3);
scene.add(dir);

// Floor & walls (simple room)
const room = new THREE.Group();
scene.add(room);

const floor = new THREE.Mesh(
  new THREE.PlaneGeometry(8,8),
  new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, metalness: 0 })
);
floor.rotation.x = -Math.PI/2;
floor.position.y = 0;
room.add(floor);

// walls
const wallMat = new THREE.MeshStandardMaterial({ color: 0xeef2f7, roughness: 1 });
const wallGeo = new THREE.PlaneGeometry(8,3);
const wall1 = new THREE.Mesh(wallGeo, wallMat); wall1.position.set(0,1.5,-4);
const wall2 = new THREE.Mesh(wallGeo, wallMat); wall2.position.set(0,1.5,4); wall2.rotation.y = Math.PI;
const wall3 = new THREE.Mesh(wallGeo, wallMat); wall3.position.set(-4,1.5,0); wall3.rotation.y = Math.PI/2;
const wall4 = new THREE.Mesh(wallGeo, wallMat); wall4.position.set(4,1.5,0); wall4.rotation.y = -Math.PI/2;
room.add(wall1, wall2, wall3, wall4);

// simple furniture blocks
function box(w,h,d,c){ return new THREE.Mesh(new THREE.BoxGeometry(w,h,d), new THREE.MeshStandardMaterial({ color:c, roughness:0.8 })); }
const sofa = box(2.2, .6, .9, 0xd1d5db); sofa.position.set(-1, .3, 0.6);
const table = box(1.0, .4, .6, 0xf3f4f6); table.position.set(1.2, .2, 0);
const cabinet = box(1.8, 1.0, .45, 0xe5e7eb); cabinet.position.set(0, .5, -2.6);
room.add(sofa, table, cabinet);

// Hotspots
const hotspotData = [
  {
    id: 'hs_epc',
    position: new THREE.Vector3(0, 1.1, -2.2),
    text: 'EPC matters: Better ratings can raise rentability and long-term value. Audit before you buy.',
  },
  {
    id: 'hs_roi',
    position: new THREE.Vector3(1.2, 0.45, 0),
    text: 'Know your numbers: Target a realistic cash-on-cash ROI and include voids, repairs, and finance.',
  },
  {
    id: 'hs_area',
    position: new THREE.Vector3(-1.1, 0.6, 0.6),
    text: 'Ethical sourcing: Choose areas that benefit from regeneration without displacing communities.',
  },
];

const hotspotMeshes = [];
const spriteMat = new THREE.SpriteMaterial({ color: 0xe43c41 });
hotspotData.forEach(h => {
  const s = new THREE.Sprite(spriteMat.clone());
  s.scale.set(0.25,0.25,0.25);
  s.position.copy(h.position);
  s.userData = { id: h.id, text: h.text, found: false };
  scene.add(s);
  hotspotMeshes.push(s);
});

// Raycasting
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();

function onPointerMove(e){
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
}
window.addEventListener('pointermove', onPointerMove);

function screenPos(worldVec){
  const v = worldVec.clone().project(camera);
  const x = (v.x * 0.5 + 0.5) * window.innerWidth;
  const y = ( -v.y * 0.5 + 0.5) * window.innerHeight;
  return { x, y };
}

let started = false;
let foundCount = 0;
let startTime = 0;
let timerInterval = null;

function startGame(){
  if(started) return;
  started = true;
  ctaBar.classList.add('hidden');
  pushEvent('start_game');
  startTime = Date.now();
  timerInterval = setInterval(updateTimer, 200);
}

function updateTimer(){
  const ms = Date.now() - startTime;
  const s = Math.floor(ms/1000);
  const m = Math.floor(s/60);
  const rems = s % 60;
  const pad = (n)=> String(n).padStart(2,'0');
  timerEl.textContent = `${pad(m)}:${pad(rems)}`;
}

function endGame(){
  clearInterval(timerInterval);
  finalTime.textContent = timerEl.textContent;
  endModal.classList.remove('hidden');
  pushEvent('level_complete', { time: timerEl.textContent, found: foundCount });
}

function onClick(e){
  if(!started) return;
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObjects(hotspotMeshes, false);
  if(hits.length){
    const obj = hits[0].object;
    const data = obj.userData;
    const pos = screenPos(obj.getWorldPosition(new THREE.Vector3()));
    tooltip.style.left = (pos.x + 12) + 'px';
    tooltip.style.top = (pos.y + 12) + 'px';
    tooltip.textContent = data.text;
    tooltip.classList.remove('hidden');
    setTimeout(()=> tooltip.classList.add('hidden'), 3500);

    if(!data.found){
      data.found = true;
      foundCount += 1;
      tipCounter.textContent = `Tips found: ${foundCount}/3`;
      pushEvent('hotspot_view', { id: data.id });
      obj.material.color.set(0x10b981); // turn green when found
      if(foundCount >= hotspotData.length){
        setTimeout(endGame, 600);
      }
    }
  }
}
window.addEventListener('click', onClick);

// Resize
function onResize(){
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}
window.addEventListener('resize', onResize);

// UI wiring
startBtn.addEventListener('click', startGame);
howBtn.addEventListener('click', ()=> howModal.classList.remove('hidden'));
closeHow.addEventListener('click', ()=> howModal.classList.add('hidden'));
replayBtn.addEventListener('click', ()=> {
  location.reload();
});

leadForm.addEventListener('submit', (e)=>{
  // basic inline validation + analytics
  const formData = new FormData(leadForm);
  if(!formData.get('name') || !formData.get('email')){
    e.preventDefault();
    alert('Please enter your name and email.');
    return;
  }
  pushEvent('form_submit', { source: '3d_mini_tour' });
  // let the form submit normally (replace action with your endpoint)
});

// Animation loop
function tick(){
  controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(tick);
}
tick();

// Idle: show how modal on first visit when not started
setTimeout(()=>{
  if(!started) howModal.classList.remove('hidden');
}, 1200);
